clc
clear
close all

%load face data
load face.mat

config

%% Data Partition

%10-fold crossvalidation
%10 items in each class and 9 data into training set, 1 into test set, same
%as leave-one-out in this case
k=10;                               %Define ratio of partition, k is the proportion sorted into test set
c = cvpartition(l,'Kfold',k);       %Create partition object

%Demonstrate with 1st set
TestIdx=test(c,1);                    %Create index list for test set
TrainingIdx=training(c,1);            %Index list for training set
test=X(:,TestIdx);              
train=X(:,TrainingIdx);

clear c k l X TestIdx TrainingIdx

test = test';
train = train';

%%

label_result = zeros(52,52);
decision_val = zeros(52,52);
b = 1;
% compensation = 0.001:0.3:6;
compensation = 6:50:500;
accuracy = zeros(size(compensation,2),1);
for c = compensation
    CorrectCount=0;
    for i = 1:52
    % creating different labels for each loop 
        label_test = -ones(52,1);
        label_test(i) = 1;
        label_train = -ones(468,1);
        label_train(((i-1)*9+1):(i*9)) = 1;

    % train and test
        svm_1vAll = fitcsvm(train,label_train,'Standardize',true,'KernelFunction','polynomial','KernelScale','auto','BoxConstraint',c);
        [label_result(:,i) score]= predict(svm_1vAll,test);
        %accuracy
        [minimum index] = min(score(:,1)); 
        if(index == i)
            CorrectCount = CorrectCount+1;
        end
        
    end
    accuracy(b) = CorrectCount/size(test,1);
    b=b+1;
end
%     [x,result] = max(decision_val);
%     accuracy = 1 - (nnz(result - (1:52))/52);
%     b = b+1;
% end
% end
%%
% sv = svm_1vAll.SVs;
% figure
% gscatter(train(:,1),train(:,2),label_train)
% hold on
% plot(sv(:,1),sv(:,2),'ko','MarkerSize',10)
% legend('1','-1','Support Vector')
% hold off




